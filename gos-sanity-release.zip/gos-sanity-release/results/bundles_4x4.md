# GoS Sanity Check — 4×4 Bundle 详情

实验结构：**4 query × 4 bundle_type = 16 cell**。pedestrian 与 protein 已补到目标 n=4（pedestrian 因 agent_timeout 实际 n=2/3/4）。crystal 与 xlsx 仍 n=1。

## 当前 4×4 reward 矩阵 (mean ± std, n)

| query | gos_original | delete_top | add_irrelevant | replace_similar |
|---|---|---|---|---|
| pedestrian | 0.084±0.076 (n=4) | 0.090±0.140 (n=4) Δ=+0.006 | 0.103±0.059 (n=2) Δ=+0.019 | 0.044±0.049 (n=3) Δ=−0.040 |
| protein | 0.500±0.500 (n=4) | 0.250±0.433 (n=4) Δ=−0.250 | 0.000±0.000 (n=4) Δ=−0.500 | 0.000±0.000 (n=4) Δ=−0.500 |
| crystal | 0.550 (n=1) | 0.550 (n=1) Δ=0 | 0.550 (n=1) Δ=0 | 0.550 (n=1) Δ=0 |
| xlsx | 0.000 (n=2) | 0.000 (n=1) Δ=0 | 0.000 (n=1) Δ=0 | 0.000 (n=1) Δ=0 |

每 cell 的 rewards 数组：
- pedestrian gos: [0.012, 0.127, 0.188, 0.009]
- pedestrian del: [0.009, 0.009, 0.009, 0.333]
- pedestrian add: [0.044, 0.163]（其余 2 次 agent_timeout）
- pedestrian rep: [0.113, 0.009, 0.009]（1 次 agent_timeout）
- protein gos: [1.0, 0.0, 1.0, 0.0]
- protein del: [1.0, 0.0, 0.0, 0.0]
- protein add: [0.0, 0.0, 0.0, 0.0]
- protein rep: [0.0, 0.0, 0.0, 0.0]

## 4 个 query（Phase B 从 30 个候选筛选）

| # | query_id | 任务类型 | gos_original reward |
|---|---|---|---|
| 1 | pedestrian-traffic-counting | 视频行人计数 | 0.127 |
| 2 | protein-expression-analysis | xlsx 蛋白表达分析 | 0.0 |
| 3 | crystallographic-wyckoff-position-analysis | 晶体学 Wyckoff 位置 | 0.55 |
| 4 | xlsx-recover-data | xlsx 数据恢复 | 0.0 |

## 4 种 bundle_type

| bundle_type | 操作 |
|---|---|
| `gos_original` | 原始 8-skill bundle（GoS PPR top-8） |
| `delete_top` | 删 PPR 最高的那 1 个（→ 7 skill） |
| `add_irrelevant` | 加 1 个 PPR=0 且 cosine<0.2 的无关 skill（→ 9 skill） |
| `replace_similar` | 把最低 PPR 那个换成 Δρ<0.05 的近邻 skill（→ 仍 8 skill，PPR 近似守恒） |

标记说明：`−` 删除 / `+` 新增 / `↔` 替换。

---

## 1. pedestrian-traffic-counting

### gos_original (run `be75d9a97f4c`, reward=**0.127**)

| skill_id | PPR |
|---|---|
| openai-vision | 0.1577 |
| ffmpeg-video-editing | 0.1545 |
| image-ocr | 0.1401 |
| pptx | 0.1158 |
| xlsx | 0.0876 |
| harbor | 0.0876 |
| openai-tts | 0.0594 |
| video-processor | 0.0481 |

### delete_top (run `0f7993a3e8b2`, reward=**0.009**) — 删 `openai-vision` (PPR=0.1577)

| skill_id | PPR |
|---|---|
| ~~openai-vision~~ | ~~0.1577 −~~ |
| ffmpeg-video-editing | 0.1545 |
| image-ocr | 0.1401 |
| pptx | 0.1158 |
| xlsx | 0.0876 |
| harbor | 0.0876 |
| openai-tts | 0.0594 |
| video-processor | 0.0481 |

### add_irrelevant (run `993a1de84bac`, reward=**0.044**) — 加 `pca-decomposition` (cosine=0.096)

| skill_id | PPR |
|---|---|
| openai-vision | 0.1577 |
| ffmpeg-video-editing | 0.1545 |
| image-ocr | 0.1401 |
| pptx | 0.1158 |
| xlsx | 0.0876 |
| harbor | 0.0876 |
| openai-tts | 0.0594 |
| video-processor | 0.0481 |
| **pca-decomposition** | **0.0000 +** |

### replace_similar (run `4db745151e4a`, reward=**0.113**) — `video-processor` ↔ `gemini-video-understanding` (Δρ=0.004)

| skill_id | PPR |
|---|---|
| openai-vision | 0.1577 |
| ffmpeg-video-editing | 0.1545 |
| image-ocr | 0.1401 |
| pptx | 0.1158 |
| xlsx | 0.0876 |
| harbor | 0.0876 |
| openai-tts | 0.0594 |
| ~~video-processor~~ → **gemini-video-understanding** | ~~0.0481~~ → **0.0438 ↔** |

---

## 2. protein-expression-analysis

### gos_original (run `447f30660f9b`, reward=**0.0**)

| skill_id | PPR |
|---|---|
| automatic-speech-recognition | 0.2190 |
| image-ocr | 0.1401 |
| pptx | 0.1158 |
| xlsx | 0.0876 |
| constraint-parser | 0.0650 |
| openai-vision | 0.0631 |
| openai-tts | 0.0594 |
| docx | 0.0350 |

### delete_top (run `e7b036d85ad5`, reward=**0.0**) — 删 `automatic-speech-recognition` (PPR=0.2190)

> 历史 smoke 试验（同 bundle_type，run_id `1d5b3bd172c5`）曾获得 reward=**1.0**，差异为 LLM 采样随机性。

| skill_id | PPR |
|---|---|
| ~~automatic-speech-recognition~~ | ~~0.2190 −~~ |
| image-ocr | 0.1401 |
| pptx | 0.1158 |
| xlsx | 0.0876 |
| constraint-parser | 0.0650 |
| openai-vision | 0.0631 |
| openai-tts | 0.0594 |
| docx | 0.0350 |

### add_irrelevant (run `50d1d193bfe5`, reward=**0.0**) — 加 `pdf-reading` (cosine=0.134)

| skill_id | PPR |
|---|---|
| automatic-speech-recognition | 0.2190 |
| image-ocr | 0.1401 |
| pptx | 0.1158 |
| xlsx | 0.0876 |
| constraint-parser | 0.0650 |
| openai-vision | 0.0631 |
| openai-tts | 0.0594 |
| docx | 0.0350 |
| **pdf-reading** | **0.0000 +** |

### replace_similar (run `c98ffcafc526`, reward=**0.0**) — `docx` ↔ `ffmpeg-video-editing` (Δρ=0.007)

| skill_id | PPR |
|---|---|
| automatic-speech-recognition | 0.2190 |
| image-ocr | 0.1401 |
| pptx | 0.1158 |
| xlsx | 0.0876 |
| constraint-parser | 0.0650 |
| openai-vision | 0.0631 |
| openai-tts | 0.0594 |
| ~~docx~~ → **ffmpeg-video-editing** | ~~0.0350~~ → **0.0279 ↔** |

---

## 3. crystallographic-wyckoff-position-analysis

### gos_original (run `f3a7dffb9104`, reward=**0.55**)

| skill_id | PPR |
|---|---|
| constraint-parser | 0.1951 |
| ffmpeg-video-editing | 0.1944 |
| academic-pdf-redaction | 0.1460 |
| flood-detection | 0.0876 |
| video-processor | 0.0605 |
| locational-marginal-prices | 0.0459 |
| segment-combiner | 0.0438 |
| reflow-profile-compliance-toolkit | 0.0346 |

### delete_top (run `a6197ec3259b`, reward=**0.55**) — 删 `constraint-parser` (PPR=0.1951)

| skill_id | PPR |
|---|---|
| ~~constraint-parser~~ | ~~0.1951 −~~ |
| ffmpeg-video-editing | 0.1944 |
| academic-pdf-redaction | 0.1460 |
| flood-detection | 0.0876 |
| video-processor | 0.0605 |
| locational-marginal-prices | 0.0459 |
| segment-combiner | 0.0438 |
| reflow-profile-compliance-toolkit | 0.0346 |

### add_irrelevant (run `41754b2a8378`, reward=**0.55**) — 加 `-2chat-automation` (cosine=0.174)

| skill_id | PPR |
|---|---|
| constraint-parser | 0.1951 |
| ffmpeg-video-editing | 0.1944 |
| academic-pdf-redaction | 0.1460 |
| flood-detection | 0.0876 |
| video-processor | 0.0605 |
| locational-marginal-prices | 0.0459 |
| segment-combiner | 0.0438 |
| reflow-profile-compliance-toolkit | 0.0346 |
| **-2chat-automation** | **0.0000 +** |

### replace_similar (run `3e3f32357b43`, reward=**0.55**) — `reflow-profile-compliance-toolkit` ↔ `casadi-ipopt-nlp` (Δρ=0.003)

| skill_id | PPR |
|---|---|
| constraint-parser | 0.1951 |
| ffmpeg-video-editing | 0.1944 |
| academic-pdf-redaction | 0.1460 |
| flood-detection | 0.0876 |
| video-processor | 0.0605 |
| locational-marginal-prices | 0.0459 |
| segment-combiner | 0.0438 |
| ~~reflow-profile-compliance-toolkit~~ → **casadi-ipopt-nlp** | ~~0.0346~~ → **0.0312 ↔** |

---

## 4. xlsx-recover-data

### gos_original (run `0ef662e204b3`, reward=**0.0**)

| skill_id | PPR |
|---|---|
| image-ocr | 0.2050 |
| pptx | 0.1695 |
| geospatial-analysis | 0.0876 |
| xlsx | 0.0876 |
| openai-tts | 0.0868 |
| constraint-parser | 0.0787 |
| data-reconciliation | 0.0564 |
| docx | 0.0350 |

### delete_top (run `b5abf454dca7`, reward=**0.0**) — 删 `image-ocr` (PPR=0.2050)

| skill_id | PPR |
|---|---|
| ~~image-ocr~~ | ~~0.2050 −~~ |
| pptx | 0.1695 |
| geospatial-analysis | 0.0876 |
| xlsx | 0.0876 |
| openai-tts | 0.0868 |
| constraint-parser | 0.0787 |
| data-reconciliation | 0.0564 |
| docx | 0.0350 |

### add_irrelevant (run `35c66da5f227`, reward=**0.0**) — 加 `suricata-offline-evejson` (cosine=0.146)

| skill_id | PPR |
|---|---|
| image-ocr | 0.2050 |
| pptx | 0.1695 |
| geospatial-analysis | 0.0876 |
| xlsx | 0.0876 |
| openai-tts | 0.0868 |
| constraint-parser | 0.0787 |
| data-reconciliation | 0.0564 |
| docx | 0.0350 |
| **suricata-offline-evejson** | **0.0000 +** |

### replace_similar (run `2359f5378868`, reward=**0.0**) — `docx` ↔ `lab-unit-harmonization` (Δρ=0.005)

| skill_id | PPR |
|---|---|
| image-ocr | 0.2050 |
| pptx | 0.1695 |
| geospatial-analysis | 0.0876 |
| xlsx | 0.0876 |
| openai-tts | 0.0868 |
| constraint-parser | 0.0787 |
| data-reconciliation | 0.0564 |
| ~~docx~~ → **lab-unit-harmonization** | ~~0.0350~~ → **0.0305 ↔** |

---

## 横向观察

| 现象 | 说明 |
|---|---|
| pedestrian 信号 | 4 cell mean 全在 0.04-0.10 区间，单 trial 标准差 0.05-0.14 远大于 cell 间 Δ（最大 \|Δ\|=0.040）→ **n=4 下无显著 perturbation 效应**，全部落在采样噪声内 |
| protein 信号 | gos→del→add/rep 单调递减 0.500 → 0.250 → 0.000 → 0.000，Bernoulli 方差大但方向清晰；add/rep 全 4 trial=0 提示 perturbation 确实压低成功率（但理论上 protein agent 不读 skills/，机制需进一步验证） |
| pedestrian timeout | 3 个 trial 撞 1h `cfg.agent.timeout_s` 上限：round1 add_irrelevant、round3 add_irrelevant + replace_similar，导致 add_irrelevant 实际 n=2 |
| crystal 异常 | 4 个 cell 全 0.55，bundle 内容完全不影响 reward → 该 query 是常数任务，无信号 |
| xlsx 信号 | 4 cell 全 0，无判别力 |
| `delete_top` 操作 | 删的全是 bundle 中 PPR 最高那个 skill |
| `add_irrelevant` 操作 | 加进来的全是 PPR=0、cosine<0.2 的"异质" skill，符合"无关"定义 |
| `replace_similar` 操作 | Δρ 全部 ≪ 0.05 epsilon 阈值（最大 0.007），走 `strict_within_epsilon`，PPR 守恒 |

**结论**：
- **protein 是当前唯一可声称扰动有效的 cell**，但 std=0.5（满方差 Bernoulli）+ n=4 下 95% CI 仍宽（gos vs add p≈0.06，gos vs del p≈0.5），统计上欠强；要支撑结论建议把 protein 4 cell 各补到 n≥8。
- pedestrian 当前结果是**反向证据**：所有 perturbation 都没有让 reward 显著低于 baseline，即"GoS 选的 bundle 比扰动后好"在 n=4 下不成立。
- pedestrian add_irrelevant n=2 的 std=0.059 也警示这个 cell 即使扩到 n=8 也大概率信号微弱。

**回到论文/sanity check 的诊断意义**：4 query 中 3 个无判别力（crystal/xlsx 常数 + pedestrian 噪声主导），只有 protein 给出方向正确但 underpowered 的扰动效应。说明当前 query/bundle 设计下，PPR 选择对实际 agent reward 的贡献远小于 LLM 采样波动；要做出有说服力的对照实验，要么换更高 reward-variance 的任务集，要么把每 cell n 推到 ≥10。
